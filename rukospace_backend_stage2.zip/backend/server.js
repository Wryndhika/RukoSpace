require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('./db');
const {authenticate, allow} = require('./auth');

const app = express();
app.use(cors({origin:true}));
app.use(express.json({limit:'2mb'}));
const commissionRate = 0.10;

app.get('/api/health', (_,res)=>res.json({status:'ok',app:'RukoSpace API'}));

app.post('/api/auth/login', async (req,res)=>{
  try {
    const {username,password}=req.body;
    const [rows]=await db.query('SELECT id,name,username,password_hash,role FROM users WHERE username=?',[username]);
    if(!rows.length || !(await bcrypt.compare(password,rows[0].password_hash)))
      return res.status(401).json({message:'Username/password salah'});
    const u=rows[0];
    const token=jwt.sign({id:u.id,name:u.name,username:u.username,role:u.role},process.env.JWT_SECRET,{expiresIn:'8h'});
    res.json({token,user:{id:u.id,name:u.name,username:u.username,role:u.role}});
  } catch(e){res.status(500).json({message:'Gagal login',error:e.message});}
});

app.post('/api/auth/register', async (req,res)=>{
  try {
    const {name,username,email,password,role='tenant'}=req.body;
    if(!name||!username||!password) return res.status(400).json({message:'Nama, username, password wajib'});
    if(!['owner','tenant'].includes(role)) return res.status(400).json({message:'Role pendaftaran hanya owner atau tenant'});
    const hash=await bcrypt.hash(password,12);
    const [r]=await db.query('INSERT INTO users(name,username,email,password_hash,role) VALUES(?,?,?,?,?)',[name,username,email||null,hash,role]);
    res.status(201).json({id:r.insertId,name,username,role});
  } catch(e){res.status(400).json({message:'Registrasi gagal. Username/email mungkin sudah digunakan.'});}
});

app.get('/api/properties', async (req,res)=>{
  const [rows]=await db.query(`SELECT p.*,u.name owner_name FROM properties p JOIN users u ON u.id=p.owner_id WHERE p.status IN ('available','rented') ORDER BY p.created_at DESC`);
  res.json(rows);
});
app.post('/api/properties', authenticate, allow('owner'), async (req,res)=>{
  const {name,address,description,price,image_url}=req.body;
  if(!name||!address||!Number.isInteger(Number(price))||Number(price)<=0) return res.status(400).json({message:'Nama, alamat, dan harga valid wajib'});
  const [r]=await db.query('INSERT INTO properties(owner_id,name,address,description,price,image_url) VALUES(?,?,?,?,?,?)',[req.user.id,name,address,description||'',price,image_url||null]);
  res.status(201).json({id:r.insertId,message:'Ruko ditambahkan'});
});
app.get('/api/owner/properties', authenticate, allow('owner'), async (req,res)=>{
  const [rows]=await db.query('SELECT * FROM properties WHERE owner_id=? ORDER BY created_at DESC',[req.user.id]); res.json(rows);
});
app.put('/api/properties/:id', authenticate, allow('owner'), async (req,res)=>{
  const {name,address,description,price,image_url,status}=req.body;
  const [r]=await db.query(`UPDATE properties SET name=?,address=?,description=?,price=?,image_url=?,status=COALESCE(?,status) WHERE id=? AND owner_id=?`,
    [name,address,description||'',price,image_url||null,status||null,req.params.id,req.user.id]);
  if(!r.affectedRows) return res.status(404).json({message:'Ruko tidak ditemukan/milik akun ini'});
  res.json({message:'Ruko diperbarui'});
});
app.delete('/api/properties/:id', authenticate, allow('owner'), async (req,res)=>{
  const [r]=await db.query(`UPDATE properties SET status='inactive' WHERE id=? AND owner_id=? AND status='available'`,[req.params.id,req.user.id]);
  if(!r.affectedRows) return res.status(400).json({message:'Ruko tidak ditemukan atau sedang disewa'});
  res.json({message:'Ruko dinonaktifkan'});
});

app.post('/api/rentals', authenticate, allow('tenant'), async (req,res)=>{
  const {property_id,start_date,end_date}=req.body;
  const conn=await db.getConnection();
  try{
    await conn.beginTransaction();
    const [p]=await conn.query('SELECT * FROM properties WHERE id=? AND status="available" FOR UPDATE',[property_id]);
    if(!p.length){await conn.rollback();return res.status(400).json({message:'Ruko tidak tersedia'});}
    const [r]=await conn.query('INSERT INTO rentals(property_id,tenant_id,start_date,end_date,total_amount) VALUES(?,?,?,?,?)',[property_id,req.user.id,start_date,end_date,p[0].price]);
    await conn.commit();res.status(201).json({rental_id:r.insertId,total_amount:p[0].price,message:'Pengajuan sewa dibuat'});
  }catch(e){await conn.rollback();res.status(500).json({message:'Gagal membuat penyewaan'});}
  finally{conn.release();}
});
app.get('/api/owner/rentals', authenticate, allow('owner'), async (req,res)=>{
  const [rows]=await db.query(`SELECT r.*,p.name property_name,u.name tenant_name FROM rentals r JOIN properties p ON p.id=r.property_id JOIN users u ON u.id=r.tenant_id WHERE p.owner_id=? ORDER BY r.created_at DESC`,[req.user.id]);res.json(rows);
});
app.get('/api/admin/summary', authenticate, allow('admin'), async (req,res)=>{
  const [[stats]]=await db.query(`SELECT COUNT(*) total_rentals, COALESCE(SUM(CASE WHEN status IN ('active','approved','completed') THEN total_amount*commission_rate/100 ELSE 0 END),0) admin_commission FROM rentals`);
  const [[counts]]=await db.query(`SELECT COUNT(*) total_properties FROM properties WHERE status!='inactive'`);
  res.json({...stats,...counts,commission_rate:commissionRate});
});
app.get('/api/owner/summary', authenticate, allow('owner'), async (req,res)=>{
  const [[s]]=await db.query(`SELECT COUNT(DISTINCT p.id) properties, COUNT(r.id) rentals, COALESCE(SUM(CASE WHEN r.status IN ('active','approved','completed') THEN r.total_amount*(1-r.commission_rate/100) ELSE 0 END),0) net_income FROM properties p LEFT JOIN rentals r ON r.property_id=p.id WHERE p.owner_id=?`,[req.user.id]);
  res.json(s);
});

// Membuat transaksi Midtrans Snap. Server key hanya dipakai di backend.
app.post('/api/payments/midtrans', authenticate, allow('tenant'), async (req,res)=>{
  if(!process.env.MIDTRANS_SERVER_KEY) return res.status(503).json({message:'Midtrans belum dikonfigurasi di .env'});
  const {rental_id}=req.body;
  const [rows]=await db.query(`SELECT r.*,p.name FROM rentals r JOIN properties p ON p.id=r.property_id WHERE r.id=? AND r.tenant_id=? AND r.status='pending'`,[rental_id,req.user.id]);
  if(!rows.length) return res.status(404).json({message:'Penyewaan tidak ditemukan'});
  const rental=rows[0], orderId='RUKO-'+rental.id+'-'+Date.now();
  const snap=require('midtrans-client');
  const client=new snap.Snap({isProduction:process.env.MIDTRANS_IS_PRODUCTION==='true',serverKey:process.env.MIDTRANS_SERVER_KEY,clientKey:process.env.MIDTRANS_CLIENT_KEY});
  const [p]=await db.query('INSERT INTO payments(rental_id,order_id,amount,gateway) VALUES(?,?,?,?)',[rental.id,orderId,rental.total_amount,'midtrans']);
  try{
    const trx=await client.createTransaction({transaction_details:{order_id:orderId,gross_amount:Number(rental.total_amount)},item_details:[{id:String(rental.id),price:Number(rental.total_amount),quantity:1,name:rental.name}],customer_details:{first_name:req.user.name}});
    res.json({payment_id:p.insertId,order_id:orderId,token:trx.token,redirect_url:trx.redirect_url});
  }catch(e){await db.query('UPDATE payments SET status="failed" WHERE id=?',[p.insertId]);res.status(502).json({message:'Midtrans gagal membuat transaksi'});}
});

// Webhook Midtrans: verifikasi signature_key sebelum update pembayaran.
app.post('/api/payments/midtrans/webhook', async (req,res)=>{
  try{
    const {order_id,status_code,gross_amount,signature_key,transaction_status}=req.body;
    const expected=crypto.createHash('sha512').update(order_id+status_code+gross_amount+process.env.MIDTRANS_SERVER_KEY).digest('hex');
    if(expected!==signature_key) return res.status(403).json({message:'Signature tidak valid'});
    let status='pending';
    if(['settlement','capture'].includes(transaction_status)) status='paid';
    else if(['deny','cancel'].includes(transaction_status)) status='failed';
    else if(transaction_status==='expire') status='expired';
    const conn=await db.getConnection();
    try{
      await conn.beginTransaction();
      const [payments]=await conn.query('SELECT * FROM payments WHERE order_id=? FOR UPDATE',[order_id]);
      if(payments.length){
        await conn.query('UPDATE payments SET status=?,gateway_transaction_id=? WHERE order_id=?',[status,req.body.transaction_id||null,order_id]);
        if(status==='paid'){
          await conn.query('UPDATE rentals SET status="active" WHERE id=?',[payments[0].rental_id]);
          await conn.query('UPDATE properties SET status="rented" WHERE id=(SELECT property_id FROM rentals WHERE id=?)',[payments[0].rental_id]);
        }
      }
      await conn.commit();res.status(200).json({received:true});
    }catch(e){await conn.rollback();res.status(500).json({message:'Webhook gagal diproses'});}
    finally{conn.release();}
  }catch(e){res.status(500).json({message:'Webhook error'});}
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`RukoSpace API berjalan di http://localhost:${port}`));
