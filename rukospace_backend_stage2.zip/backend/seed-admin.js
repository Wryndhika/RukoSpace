require('dotenv').config();
const bcrypt=require('bcryptjs');
const db=require('./db');
(async()=>{
  const hash=await bcrypt.hash('admin123',12);
  await db.query(`INSERT INTO users(name,username,email,password_hash,role) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE role='admin'`,
    ['Administrator','admin','admin@rukospace.local',hash,'admin']);
  console.log('Admin seed dibuat: admin / admin123 (ganti password setelah login)');
  await db.end();
})().catch(e=>{console.error(e);process.exit(1)});
