const jwt = require('jsonwebtoken');
const db = require('./db');

function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({message:'Token tidak ditemukan'});
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({message:'Token tidak valid atau kedaluwarsa'});
  }
}
function allow(...roles) {
  return (req,res,next) => roles.includes(req.user.role)
    ? next() : res.status(403).json({message:'Akses ditolak untuk role ini'});
}
module.exports = {authenticate, allow};
