# RukoSpace Backend (Node.js + MySQL)

Backend tahap 2 untuk project kuliah RukoSpace. Ini merupakan API dasar; frontend ZIP awal masih menggunakan LocalStorage dan perlu dihubungkan ke endpoint API (lihat bagian integrasi).

## Stack
- Node.js + Express
- MySQL
- JWT + bcrypt
- Midtrans Snap (sandbox)

## Instalasi Windows
1. Install Node.js LTS dan MySQL (XAMPP bisa digunakan).
2. Buka terminal VS Code di folder `backend`.
3. Jalankan:
   ```bash
   npm install
   ```
4. Buat database: buka phpMyAdmin, pilih tab Import, import `schema.sql`.
5. Salin `.env.example` menjadi `.env`, lalu sesuaikan konfigurasi DB dan JWT_SECRET.
6. Buat admin:
   ```bash
   node seed-admin.js
   ```
7. Jalankan API:
   ```bash
   npm run dev
   ```
8. Cek `http://localhost:3000/api/health`.

## Akun awal
Admin: `admin` / `admin123`. Ubah password demo untuk deployment.

## Endpoint utama
- `POST /api/auth/login`
- `POST /api/auth/register` (role owner/tenant; admin tidak bisa dibuat lewat endpoint publik)
- `GET /api/properties`
- `POST /api/properties` (owner)
- `GET /api/owner/properties` (owner)
- `PUT /api/properties/:id` (owner, hanya ruko miliknya)
- `DELETE /api/properties/:id` (owner, soft-delete ruko tersedia)
- `POST /api/rentals` (tenant)
- `GET /api/owner/rentals` (owner)
- `GET /api/owner/summary` (owner)
- `GET /api/admin/summary` (admin)
- `POST /api/payments/midtrans` (tenant)
- `POST /api/payments/midtrans/webhook` (webhook Midtrans)

## Perhatian keamanan
- Role admin tidak bisa menambahkan ruko. API ruko hanya mengizinkan role `owner`.
- Token JWT dikirim pada header `Authorization: Bearer <token>`.
- Jangan commit file `.env`, jangan taruh Server Key gateway di frontend.
- Webhook harus diverifikasi. Untuk produksi, tambah logging, idempotency, validasi jumlah, dan konfigurasi HTTPS.
- Upload gambar untuk versi ini menggunakan `image_url` (URL gambar). Upload file lokal langsung sebaiknya memakai middleware upload (multer) dan penyimpanan cloud/object storage.
- Midtrans belum aktif tanpa kredensial akun Sandbox. Xendit belum dipasang pada starter ini.

## Integrasi frontend yang masih diperlukan
Frontend awal `app.js` masih memakai LocalStorage. Tahap selanjutnya adalah mengganti fungsi login, daftar ruko, rental, dan payment pada `app.js` dengan `fetch('/api/...')` (atau base URL API) dan menyimpan JWT di sesi browser. Jangan anggap API starter ini sudah otomatis tersambung ke UI lama.
