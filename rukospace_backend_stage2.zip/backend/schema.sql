CREATE DATABASE IF NOT EXISTS rukospace CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rukospace;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  username VARCHAR(60) NOT NULL UNIQUE,
  email VARCHAR(160) UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','owner','tenant') NOT NULL DEFAULT 'tenant',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS properties (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  address VARCHAR(255) NOT NULL,
  description TEXT,
  price BIGINT UNSIGNED NOT NULL,
  image_url TEXT,
  status ENUM('available','rented','inactive') NOT NULL DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS rentals (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  property_id BIGINT UNSIGNED NOT NULL,
  tenant_id BIGINT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_amount BIGINT UNSIGNED NOT NULL,
  commission_rate DECIMAL(5,2) NOT NULL DEFAULT 10.00,
  status ENUM('pending','approved','active','rejected','completed') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (property_id) REFERENCES properties(id),
  FOREIGN KEY (tenant_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rental_id BIGINT UNSIGNED NOT NULL,
  order_id VARCHAR(100) NOT NULL UNIQUE,
  amount BIGINT UNSIGNED NOT NULL,
  gateway VARCHAR(30) NOT NULL DEFAULT 'midtrans',
  gateway_transaction_id VARCHAR(120),
  status ENUM('pending','paid','failed','expired','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rental_id) REFERENCES rentals(id)
);

-- Jalankan seed admin setelah install:
-- node seed-admin.js
